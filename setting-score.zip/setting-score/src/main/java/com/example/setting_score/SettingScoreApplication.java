package com.example.setting_score;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SettingScoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(SettingScoreApplication.class, args);
	}

}
